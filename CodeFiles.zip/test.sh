#!bin/bash
mkdir -p /localdisk/home/s1921796/Assignment1
cd Assignment1

# Copy files from localdisk
cp -R /localdisk/data/BPSM/Assignment1/fastq .

# Excute FASTQC
mkdir QC_output
cd fastq
for file in *.fq.gz;
do gunzip ${file};
done

for file in *.fq;
do fastqc -f fastq -o ~/Assignment1/QC_output/ -q ${file};
done

# Unzip all *.zip
cd ~/Assignment1/QC_output/
for file in *.zip;
do unzip -nq $file;
done

# Combine and sum up all results
cat */summary.txt > ~/Assignment1/QC_output/fastqc_summaries.txt
grep FAIL fastqc_summaries.txt > fastqc_summaries_fw.txt
grep WARN fastqc_summaries.txt >> fastqc_summaries_fw.txt | less -S

# Preparation
cd ~/Assignment1
cp -R /localdisk/data/BPSM/Assignment1/Tbb_genome/ .
cd Tbb_genome
gunzip *fasta.gz

# Set up bowtie2 index
bowtie2-build Tb927_genome.fasta Tb927_genome_index

# Align the read pairs
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/216_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/216_L8_2.fq -S 216_L8_output.sam
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/218_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/218_L8_2.fq -S 218_L8_output.sam
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/219_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/219_L8_2.fq -S 219_L8_output.sam
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/220_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/220_L8_2.fq -S 220_L8_output.sam
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/221_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/221_L8_2.fq -S 221_L8_output.sam
bowtie2 -p 8 -x Tb927_genome_index -1 /localdisk/home/s1921796/Assignment1/fastq/222_L8_1.fq -2 /localdisk/home/s1921796/Assignment1/fastq/222_L8_2.fq -S 222_L8_output.sam

# Format transferred and sort the data
samtools view -bS 216_L8_output.sam > 216_L8_output.bam
samtools view -bS 218_L8_output.sam > 218_L8_output.bam
samtools view -bS 219_L8_output.sam > 219_L8_output.bam
samtools view -bS 220_L8_output.sam > 220_L8_output.bam
samtools view -bS 221_L8_output.sam > 221_L8_output.bam
samtools view -bS 222_L8_output.sam > 222_L8_output.bam

samtools sort 216_L8_output.bam -o 216_L8_output.sorted.bam
samtools sort 218_L8_output.bam -o 218_L8_output.sorted.bam
samtools sort 219_L8_output.bam -o 219_L8_output.sorted.bam
samtools sort 220_L8_output.bam -o 220_L8_output.sorted.bam
samtools sort 221_L8_output.bam -o 221_L8_output.sorted.bam
samtools sort 222_L8_output.bam -o 222_L8_output.sorted.bam

samtools index 216_L8_output.sorted.bam 
samtools index 218_L8_output.sorted.bam
samtools index 219_L8_output.sorted.bam
samtools index 220_L8_output.sorted.bam
samtools index 221_L8_output.sorted.bam
samtools index 222_L8_output.sorted.bam

# Count
cd ~/Assignment1
cp -R /localdisk/data/BPSM/Assignment1/Tbbgenes.bed .
bedtools multicov -bams 216_L8_output.sorted.bam 218_L8_output.sorted.bam 219_L8_output.sorted.bam -bed Tbbgenes.bed > Tb927_slender.txt
bedtools multicov -bams 220_L8_output.sorted.bam 221_L8_output.sorted.bam 222_L8_output.sorted.bam -bed Tbbgenes.bed > Tb927_stumpy.txt

# Sum up and add title
cat Tb927_slender.txt | awk -v group=slender '{FS="\t";OFS="\t";{sum = 0; for (i = 7; i <= NF; i++) sum += $i; sum /= NF; print $4, group ": " sum}}' > slender_mean.txt
cat Tb927_stumpy.txt | awk -v group=stumpy '{FS="\t";OFS="\t";{sum = 0; for (i = 7; i <= NF; i++) sum += $i; sum /= NF; print $4, group ": " sum}}' > stumpy_mean.txt
join slender_mean.txt stumpy_mean.txt > Tb927_mean.txt
sed -i '1i gene_name\tmean' Tb927_mean.txt
